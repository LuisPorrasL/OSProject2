#include "syscall.h"

int main(){
    Write("¡Brillo!", 9, 1);
	return 0;
}
