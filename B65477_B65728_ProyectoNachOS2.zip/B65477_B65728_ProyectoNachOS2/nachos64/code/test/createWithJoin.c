int main(){
	long id = Exec("../test/brillo");
    Join(id);

	Write("Prueba", 6, 1);

	Exit(0);
	return 0;
}
