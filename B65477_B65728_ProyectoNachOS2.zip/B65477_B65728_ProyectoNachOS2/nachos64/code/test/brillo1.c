#include "syscall.h"

int main(){
    Write("¡Brillo 1 / Oscuridad 0!", 25, 1);
	return 0;
}
